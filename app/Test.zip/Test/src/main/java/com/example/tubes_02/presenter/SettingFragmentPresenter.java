package com.example.tubes_02.presenter;

public class SettingFragmentPresenter {
}
